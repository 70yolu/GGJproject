English
You can use sytem voice for private use only.

Japanese
特に何も考えない場合は、私的使用の範囲内でご利用ください。
もっと活用したい場合は、利用ガイドラインをお読みください。
http://pronama.azurewebsites.net/pronama/guideline/
